create function age(timestamp with time zone) returns interval
    stable
    strict
    parallel safe
    cost 1
    language sql
RETURN age((CURRENT_DATE)::timestamp with time zone, $1);

comment on function age(timestamp with time zone, unknown) is 'date difference from today preserving months and years';

alter function age(timestamp with time zone, unknown) owner to postgres;

