create view pg_stat_subscription
            (subid, subname, pid, leader_pid, relid, received_lsn, last_msg_send_time, last_msg_receipt_time,
             latest_end_lsn, latest_end_time)
as
SELECT su.oid AS subid,
       su.subname,
       st.pid,
       st.leader_pid,
       st.relid,
       st.received_lsn,
       st.last_msg_send_time,
       st.last_msg_receipt_time,
       st.latest_end_lsn,
       st.latest_end_time
FROM pg_subscription su
         LEFT JOIN pg_stat_get_subscription(NULL::oid) st(subid, relid, pid, leader_pid, received_lsn,
                                                          last_msg_send_time, last_msg_receipt_time, latest_end_lsn,
                                                          latest_end_time) ON st.subid = su.oid;

alter table pg_stat_subscription
    owner to postgres;

grant select on pg_stat_subscription to public;

